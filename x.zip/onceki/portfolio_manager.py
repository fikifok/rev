# portfolio_manager.py – Modül stub
class PortfolioManager:
    """Modül 4: (Henüz implement edilecek)"""
    pass
